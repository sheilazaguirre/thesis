<?php
	$server = "localhost";
	$database = "thesis";
	$username = "root";
	$password = "";

	$con = new mysqli($server, $username, $password, $database);

?>